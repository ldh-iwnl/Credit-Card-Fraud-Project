**********************
*	Group No.26		*
*	By				*
*	Wang Weishi		*
*	Li Dongheng		*
*	Gao Peiyan		*
*	Mak Lam			*
*	Xie Ning			*
**********************
dataset: https://www.kaggle.com/datasets/dhanushnarayananr/credit-card-fraud

Getting the same graph as in our report need running by rscript.
*Sample use:
*rscript knn.R
**May need manually install some packages.